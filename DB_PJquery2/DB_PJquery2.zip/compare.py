import os
os.chdir('C:\\Studying\\myvenv\\etc\\DB_PJquery2')

with open('.\\US.txt', 'rt') as f:
    US_opener= f.readlines()
    for elmt in US_opener:
        elmt= elmt[:-3]
print(US_opener)
with open('.\\OHTER.txt', 'rt') as f2:
    OTHER_opener= f2.readlines()
    for elmt in OTHER_opener:
        elmt= elmt[:-3]

with open('compare.txt', 'wt') as f3:
    for i, [u, o] in enumerate(zip(US_opener, OTHER_opener)):
        if u != o:
            f3.write(str([i, u, o])+ '\n')
